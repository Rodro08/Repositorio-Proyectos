enum TotalTravelAction {
  actionA,
  actionB,
}
